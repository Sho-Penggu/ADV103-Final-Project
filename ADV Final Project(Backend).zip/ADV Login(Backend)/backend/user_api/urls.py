from django.urls import path
from . import views

urlpatterns = [
	path('register', views.UserRegister.as_view(), name='register'),
	path('login', views.UserLogin.as_view(), name='login'),
	path('logout', views.UserLogout.as_view(), name='logout'),
	path('user', views.UserView.as_view(), name='user'),
 
 	#path('1', views.getRoutes, name="routes"),
  
	path('home', views.Sanction.as_view({
		'get': 'list',
		'post': 'post'
	})),
 
	path('home/<int:pk>', views.Sanction.as_view({
		'put': 'put',
		'patch': 'patch',
		'delete': 'delete',
		'get': 'get'
	}))
 
 
    ##path('sanctions/', views.GetSanctions.as_view(), name="sanctions"),
    #path('sanctions/<str:pk>/update/', views.UpdateSanction.as_view(), name="update-sanction"),
    #path('sanctions/<str:pk>/', views.GetSanctionID.as_view(), name="sanctionID"),
]